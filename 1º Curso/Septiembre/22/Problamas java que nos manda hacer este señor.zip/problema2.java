public class problema2 {

	public static void main(String[] args) {
		//Declaración de variables
		double area;
		double base;
		double altura;
		//Inicialización
		base = 5.5;
		altura = 144.9676;
		//Entrada de datos
		area = base * altura;
		//Operativa y salida de información
		System.out.println("El resultado es: " + area);
		System.out.println("El area es:" + (7 + 6));

	}

}