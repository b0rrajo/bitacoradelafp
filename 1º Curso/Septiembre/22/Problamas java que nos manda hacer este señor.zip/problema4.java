import java.util.Scanner;
public class problema4 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//Declaración de variables
		int b;
		int a;
		int aux;
		//Inicialización
		a = (int) scanner.nextDouble();
		b = (int) scanner.nextDouble();
		System.out.println("a = "+ a + ", b = " + b);
		//Entrada de datos
		//Operativa
		a = a + b;
		b = a - b;
		a = a - b;
		
		//salida de información
		System.out.println("a = " + a + ", b = " + b);
	}

}