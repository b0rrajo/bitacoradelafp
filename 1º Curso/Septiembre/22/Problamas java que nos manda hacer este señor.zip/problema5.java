import java.util.Scanner;
public class problema5 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		//Declaración de variables
		int a;
		int b;
		int c;
		int s1;
		int s2;
		//Inicialización
		System.out.println("Dame X");
		a = (int) teclado.nextDouble();
		System.out.println("Dame Y");
		b = (int) teclado.nextDouble();
		System.out.println("Dame Z");
		c = (int) teclado.nextDouble();
		//Entrada de datos
		s1 = (int) (((- b) + Math.sqrt((b * b)-(4 * a * c))) / (2 * a));
		//Operativa
	
		//salida de información
		System.out.println("Resultado: " + s1);
	}
}