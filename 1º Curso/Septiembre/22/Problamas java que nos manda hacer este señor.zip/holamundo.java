public class holamundo {
	public static void main(String[] args) {
		double base = 10;
		double altura = 20;
		double area = (base * altura) / 2;
		System.out.println("Área: " + area);
	}
}