public class problema3 {

	public static void main(String[] args) {
		//Declaración de variables
		double area;
		double radio;
		final double PI = 3.1416;
		//Inicialización
		radio = 10;
		//Entrada de datos
		area = Math.PI * Math.pow(radio, 2);
		//Operativa y salida de información
		System.out.println("El area de un circulo de radio " + radio + " es : " + area);

	}

}