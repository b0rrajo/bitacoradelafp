public class problema01 {

	public static void main(String[] args) {
		//Declaración de variables
		double num1;
		double num2;
		double sol;
		//Inicialización
		num1 = 5.5;
		num2 = 144.9676;
		//Entrada de datos
		sol = num1 + num2;
		//Operativa y salida de información
		System.out.println("el numero dado es " + sol);

	}

}